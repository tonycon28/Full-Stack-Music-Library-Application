const db = require("../db");

// GET all albums
exports.getAll = (req, res) => {
    db.all("SELECT * FROM albums", [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
};

// GET one album
exports.getOne = (req, res) => {
    db.get(
        "SELECT * FROM albums WHERE album_id = ?",
        [req.params.id],
        (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(row);
        }
    );
};

// CREATE album
exports.create = (req, res) => {
    const { name, release_year, listens, artist_id } = req.body;

    db.run(
        "INSERT INTO albums (name, release_year, listens, artist_id) VALUES (?, ?, ?, ?)",
        [name, release_year, listens, artist_id],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ id: this.lastID });
        }
    );
};

// UPDATE album
exports.update = (req, res) => {
    const { name, release_year, listens, artist_id } = req.body;

    db.run(
        "UPDATE albums SET name=?, release_year=?, listens=?, artist_id=? WHERE album_id=?",
        [name, release_year, listens, artist_id, req.params.id],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ updated: this.changes });
        }
    );
};

// DELETE album
exports.remove = (req, res) => {
    db.run(
        "DELETE FROM albums WHERE album_id=?",
        [req.params.id],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ deleted: this.changes });
        }
    );
};