const db = require("../db");

// GET all artists
exports.getAll = (req, res) => {
    db.all("SELECT * FROM artists", [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
};

// GET one artist
exports.getOne = (req, res) => {
    db.get(
        "SELECT * FROM artists WHERE artist_id = ?",
        [req.params.id],
        (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(row);
        }
    );
};

// CREATE artist
exports.create = (req, res) => {
    const { name, genre, monthly_listeners } = req.body;

    db.run(
        "INSERT INTO artists (name, genre, monthly_listeners) VALUES (?, ?, ?)",
        [name, genre, monthly_listeners],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ id: this.lastID });
        }
    );
};

// UPDATE artist
exports.update = (req, res) => {
    const { name, genre, monthly_listeners } = req.body;

    db.run(
        "UPDATE artists SET name=?, genre=?, monthly_listeners=? WHERE artist_id=?",
        [name, genre, monthly_listeners, req.params.id],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ updated: this.changes });
        }
    );
};

// DELETE artist
exports.remove = (req, res) => {
    db.run(
        "DELETE FROM artists WHERE artist_id=?",
        [req.params.id],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ deleted: this.changes });
        }
    );
};