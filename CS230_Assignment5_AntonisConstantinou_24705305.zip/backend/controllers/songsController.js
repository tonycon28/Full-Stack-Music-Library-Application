const db = require("../db");

// GET all songs
exports.getAll = (req, res) => {
    db.all("SELECT * FROM songs", [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
};

// GET one song
exports.getOne = (req, res) => {
    db.get(
        "SELECT * FROM songs WHERE song_id = ?",
        [req.params.id],
        (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(row);
        }
    );
};

// CREATE song
exports.create = (req, res) => {
    const { name, release_year, album_id } = req.body;

    db.run(
        "INSERT INTO songs (name, release_year, album_id) VALUES (?, ?, ?)",
        [name, release_year, album_id],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ id: this.lastID });
        }
    );
};

// UPDATE song
exports.update = (req, res) => {
    const { name, release_year, album_id } = req.body;

    db.run(
        "UPDATE songs SET name=?, release_year=?, album_id=? WHERE song_id=?",
        [name, release_year, album_id, req.params.id],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ updated: this.changes });
        }
    );
};

// DELETE song
exports.remove = (req, res) => {
    db.run(
        "DELETE FROM songs WHERE song_id=?",
        [req.params.id],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ deleted: this.changes });
        }
    );
};