const sqlite3 = require("sqlite3").verbose();
const fs = require("fs");
const path = require("path");

// Path to database file
const dbPath = path.join(__dirname, "data", "app.db");

// Create/connect database
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) console.error(err.message);
    else console.log("Connected to SQLite DB");
});

// Run SQL schema
const sql = fs.readFileSync(path.join(__dirname, "model.sql")).toString();

db.exec(sql, (err) => {
    if (err) console.error("Error running model.sql:", err.message);
    else console.log("Database initialized");
});

module.exports = db;