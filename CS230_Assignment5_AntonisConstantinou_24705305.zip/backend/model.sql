PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS songs;
DROP TABLE IF EXISTS albums;
DROP TABLE IF EXISTS artists;

CREATE TABLE artists (
    artist_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    genre TEXT,
    monthly_listeners INTEGER
);

CREATE TABLE albums (
    album_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    release_year INTEGER,
    listens INTEGER,
    artist_id INTEGER,
    FOREIGN KEY (artist_id) REFERENCES artists(artist_id) ON DELETE CASCADE
);

CREATE TABLE songs (
    song_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    release_year INTEGER,
    album_id INTEGER,
    FOREIGN KEY (album_id) REFERENCES albums(album_id) ON DELETE CASCADE
);

-- Sample data
INSERT INTO artists (name, genre, monthly_listeners) VALUES
('Drake', 'Hip-Hop', 80000000),
('Taylor Swift', 'Pop', 100000000);

INSERT INTO albums (name, release_year, listens, artist_id) VALUES
('Scorpion', 2018, 5000000, 1),
('Certified Lover Boy', 2021, 4000000, 1),
('1989', 2014, 6000000, 2),
('Lover', 2019, 3000000, 2),
('Midnights', 2022, 7000000, 2);

INSERT INTO songs (name, release_year, album_id) VALUES
('Gods Plan', 2018, 1),
('In My Feelings', 2018, 1),
('Way 2 Sexy', 2021, 2),
('Shake It Off', 2014, 3),
('Blank Space', 2014, 3),
('Lover Song', 2019, 4),
('Cardigan', 2020, 4),
('Anti-Hero', 2022, 5),
('Lavender Haze', 2022, 5),
('Bejeweled', 2022, 5);