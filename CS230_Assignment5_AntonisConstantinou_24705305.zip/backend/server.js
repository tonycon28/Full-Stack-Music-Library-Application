const express = require("express");
const cors = require("cors");

require("./db");

const app = express();

app.use(cors()); //  This fixes fetch failed
app.use(express.json());

// Routes
app.use("/artists", require("./routes/artists"));
app.use("/albums", require("./routes/albums"));
app.use("/songs", require("./routes/songs"));

app.get("/", (req, res) => {
    res.json({ message: "API is working" });
});

app.listen(5000, () => {
    console.log("Server running on http://localhost:5000");
});