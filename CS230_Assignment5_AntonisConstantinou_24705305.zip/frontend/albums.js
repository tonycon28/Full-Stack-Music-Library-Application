const API = "http://localhost:5000/albums";

window.onload = loadAlbums;

async function loadAlbums() {
  const res = await fetch(API);
  const data = await res.json();

  const table = document.getElementById("albumTable");
  table.innerHTML = "";

  data.forEach(a => {
    table.innerHTML += `
      <tr>
        <td>${a.album_id}</td>
        <td>${a.name}</td>
        <td>${a.release_year}</td>
        <td>${a.listens}</td>
        <td>${a.artist_id}</td>
        <td>
          <button onclick='editAlbum(${JSON.stringify(a.album_id)}, ${JSON.stringify(a.name)}, ${JSON.stringify(a.release_year)}, ${JSON.stringify(a.listens)}, ${JSON.stringify(a.artist_id)})'>Edit</button>
          <button onclick="deleteAlbum(${a.album_id})">Delete</button>
        </td>
      </tr>
    `;
  });
}

async function saveAlbum() {
  const id = document.getElementById("albumId").value;

  const data = {
    name: document.getElementById("name").value,
    release_year: document.getElementById("year").value,
    listens: document.getElementById("listens").value,
    artist_id: document.getElementById("artistId").value
  };

  if (id) {
    await fetch(`${API}/${id}`, {
      method: "PUT",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
  } else {
    await fetch(API, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
  }

  clearForm();
  loadAlbums();
}

function editAlbum(id, name, year, listens, artist_id) {
  document.getElementById("albumId").value = id;
  document.getElementById("name").value = name;
  document.getElementById("year").value = year;
  document.getElementById("listens").value = listens;
  document.getElementById("artistId").value = artist_id;
}

async function deleteAlbum(id) {
  await fetch(`${API}/${id}`, { method: "DELETE" });
  loadAlbums();
}

function clearForm() {
  document.getElementById("albumId").value = "";
  document.getElementById("name").value = "";
  document.getElementById("year").value = "";
  document.getElementById("listens").value = "";
  document.getElementById("artistId").value = "";
}