const API = "http://localhost:5000";

// GET all artists
async function loadArtists() {
    const res = await fetch(`${API}/artists`);
    const data = await res.json();

    const table = document.getElementById("artistsTable");
    table.innerHTML = "";

    data.forEach(a => {
        table.innerHTML += `
            <tr>
                <td>${a.artist_id}</td>
                <td>${a.name}</td>
                <td>${a.genre}</td>
                <td>${a.monthly_listeners}</td>
            </tr>
        `;
    });
}

// CREATE artist
async function addArtist() {
    const name = document.getElementById("name").value;
    const genre = document.getElementById("genre").value;
    const listeners = document.getElementById("listeners").value;

    await fetch(`${API}/artists`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            name,
            genre,
            monthly_listeners: listeners
        })
    });

    loadArtists();
}

// load on page open
if (document.getElementById("artistsTable")) {
    loadArtists();
}