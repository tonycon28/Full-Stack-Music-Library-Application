// ================= API BASE =================
const API = "http://localhost:5000/artists";

window.onload = loadArtists;

/* ================= LOAD ARTISTS ================= */
async function loadArtists() {
  const res = await fetch(API);
  const data = await res.json();

  const table = document.getElementById("artistTable");
  table.innerHTML = "";

  data.forEach(a => {
    table.innerHTML += `
      <tr>
        <td>${a.artist_id}</td>
        <td>${a.name}</td>
        <td>${a.genre}</td>
        <td>${a.monthly_listeners}</td>
        <td>
          <button onclick='editArtist(${JSON.stringify(a.artist_id)}, ${JSON.stringify(a.name)}, ${JSON.stringify(a.genre)}, ${JSON.stringify(a.monthly_listeners)})'>Edit</button>
          <button onclick="deleteArtist(${a.artist_id})">Delete</button>
        </td>
      </tr>
    `;
  });
}

/* ================= CREATE / UPDATE ================= */
async function saveArtist() {

  const id = document.getElementById("artistId").value;

  const data = {
    name: document.getElementById("name").value,
    genre: document.getElementById("genre").value,
    monthly_listeners: document.getElementById("listeners").value
  };

  // UPDATE
  if (id) {
    await fetch(`${API}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
  }
  // CREATE
  else {
    await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
  }

  clearForm();
  loadArtists();
}

/* ================= EDIT ARTIST ================= */
function editArtist(id, name, genre, listeners) {
  document.getElementById("artistId").value = id;
  document.getElementById("name").value = name;
  document.getElementById("genre").value = genre;
  document.getElementById("listeners").value = listeners;
}

/* ================= DELETE ================= */
async function deleteArtist(id) {
  await fetch(`${API}/${id}`, { method: "DELETE" });
  loadArtists();
}

/* ================= CLEAR FORM ================= */
function clearForm() {
  document.getElementById("artistId").value = "";
  document.getElementById("name").value = "";
  document.getElementById("genre").value = "";
  document.getElementById("listeners").value = "";
}