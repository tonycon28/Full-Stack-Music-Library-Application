const API = "http://localhost:5000/songs";

window.onload = loadSongs;

async function loadSongs() {
  const res = await fetch(API);
  const data = await res.json();

  const table = document.getElementById("songTable");
  table.innerHTML = "";

  data.forEach(s => {
    table.innerHTML += `
      <tr>
        <td>${s.song_id}</td>
        <td>${s.name}</td>
        <td>${s.release_year}</td>
        <td>${s.album_id}</td>
        <td>
          <button onclick='editSong(${JSON.stringify(s.song_id)}, ${JSON.stringify(s.name)}, ${JSON.stringify(s.release_year)}, ${JSON.stringify(s.album_id)})'>Edit</button>
          <button onclick="deleteSong(${s.song_id})">Delete</button>
        </td>
      </tr>
    `;
  });
}

async function saveSong() {
  const id = document.getElementById("songId").value;

  const data = {
    name: document.getElementById("name").value,
    release_year: document.getElementById("year").value,
    album_id: document.getElementById("albumId").value
  };

  if (id) {
    await fetch(`${API}/${id}`, {
      method: "PUT",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
  } else {
    await fetch(API, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
  }

  clearForm();
  loadSongs();
}

function editSong(id, name, year, album_id) {
  document.getElementById("songId").value = id;
  document.getElementById("name").value = name;
  document.getElementById("year").value = year;
  document.getElementById("albumId").value = album_id;
}

async function deleteSong(id) {
  await fetch(`${API}/${id}`, { method: "DELETE" });
  loadSongs();
}

function clearForm() {
  document.getElementById("songId").value = "";
  document.getElementById("name").value = "";
  document.getElementById("year").value = "";
  document.getElementById("albumId").value = "";
}